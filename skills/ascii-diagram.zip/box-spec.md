# ASCII Box Diagram Spec

## Table of Contents

1. [Terminology](#terminology)
2. [Rules](#rules)
3. [Programmatic Validation](#programmatic-validation)
4. [Arrows and Connectors](#arrows-and-connectors)
5. [Layout Patterns](#layout-patterns)

---

## Terminology

- **Box**: a rectangular region bounded by border characters
- **Border**: the `|`, `-`, `+` characters forming the perimeter
- **Content**: the text inside a box (excluding borders)
- **Padding**: spaces between content and border (always exactly 1 space)
- **Corner**: `+` at every intersection of horizontal and vertical borders
- **Arrow**: a directional connector between boxes using `-`, `|`, `<`, `>`, `^`, `v`

## Rules

1. **Corner**: `+` at every intersection of horizontal and vertical borders
2. **Horizontal border**: `-` characters spanning between corners on top/bottom edges
3. **Vertical border**: `|` characters spanning between corners on left/right edges
4. **Width**: determined by the longest content line + 4 (1 border + 1 pad + content + 1 pad + 1 border)
5. **Vertical borders are contiguous**: every row between the top and bottom corners must have a `|` (or `+`) at that exact column
6. **Horizontal borders are contiguous**: every column between the left and right corners must have a `-` (or `+`) at that exact row

## Programmatic Validation

Given a box, verify it by:

1. Find all `+` positions -- these define corners
2. For each pair of corners on the same row, verify `-` fills every column between them
3. For each pair of corners on the same column, verify `|` fills every row between them
4. For each content row inside a box:
   - `col[left_border] + 1 == space` (left pad)
   - `col[right_border] - 1 == space` (right pad)
5. Box width == max(len(content_line) for all content lines) + 4

Width rule (step 5) is a WARNING not an error -- boxes may be intentionally wider
than their content for visual alignment with sibling boxes.

## Arrows and Connectors

Arrows connect boxes but are NOT validated as part of box structure. They exist
in the whitespace between boxes.

### Horizontal arrows
```
+-------+          +-------+
| Box A |--------->| Box B |
+-------+          +-------+
```

### Vertical arrows
```
+-------+
| Box A |
+-------+
    |
    v
+-------+
| Box B |
+-------+
```

### Arrow characters
- Horizontal shaft: `-`
- Vertical shaft: `|`
- Rightward head: `>`
- Leftward head: `<`
- Downward head: `v`
- Upward head: `^`

Arrows must connect to a box border character (`|` or `-`) or extend from
the whitespace adjacent to a border. Do not place arrowheads inside box borders.

## Layout Patterns

### Column alignment

When multiple boxes appear in a vertical column, align their left and right
borders to the same column positions. Use uniform width even if content
lengths differ -- the width warnings from validation are expected here.

```
+---------------------+
|        Base         |
+---------------------+

+---------------------+
|    User message     |
+---------------------+
```

### Side-by-side boxes

Separate columns with consistent gutters (8-12 spaces typical).

```
+-------------+          +-------------+
|   Parent    |          |    Child    |
+-------------+          +-------------+
```

### Nested context (column labels instead of nesting)

True nested boxes (box inside box) are valid but complex. When arrows cross
outer borders, prefer labeled columns over nesting:

```
  Parent                     Child

  +----------+          +----------+
  |  Inner1  |--------->|  Inner2  |
  +----------+          +----------+
```

### Multi-line content boxes

Content can span multiple lines. All lines share the same left/right borders:

```
+---------------------+
|       Task()        |
| "Find where XYZ     |
|   is handled"       |
+---------------------+
```

### Free-floating labels

Text outside any box (titles, annotations, column headers) is allowed and
ignored by the validator. Place them in whitespace regions that don't
interfere with box borders or arrows.
