#!/usr/bin/env python3
"""
ASCII Box Diagram Validator

Validates ASCII box diagrams per the box-spec.md rules:
- Discovers boxes by finding rectangles of + corners with valid edges
- Validates padding (exactly 1 space) and width consistency
- Reports suspected incomplete boxes (near-misses) as warnings

Usage:
    python validate_ascii.py <diagram_file>
    python validate_ascii.py --json <diagram_file>

Exit codes:
    0 = no errors
    1 = errors found
"""

import sys
import json
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Corner:
    row: int
    col: int


@dataclass
class Box:
    top_left: Corner
    top_right: Corner
    bottom_left: Corner
    bottom_right: Corner
    content_lines: list = field(default_factory=list)

    @property
    def width(self) -> int:
        return self.top_right.col - self.top_left.col + 1

    @property
    def height(self) -> int:
        return self.bottom_left.row - self.top_left.row + 1


@dataclass
class Issue:
    severity: str  # "error" or "warning"
    message: str
    row: int = -1
    col: int = -1
    fix_hint: Optional[str] = None

    def __str__(self):
        loc = ""
        if self.row >= 0:
            loc = f" (row {self.row}, col {self.col})" if self.col >= 0 else f" (row {self.row})"
        hint = f" [FIX: {self.fix_hint}]" if self.fix_hint else ""
        return f"[{self.severity.upper()}]{loc} {self.message}{hint}"

    def to_dict(self):
        d = {"severity": self.severity, "message": self.message}
        if self.row >= 0:
            d["row"] = self.row
        if self.col >= 0:
            d["col"] = self.col
        if self.fix_hint:
            d["fix_hint"] = self.fix_hint
        return d


def load_grid(text: str) -> list[str]:
    """Load text into a list of strings, padded to uniform width."""
    lines = text.rstrip("\n").split("\n")
    max_width = max((len(l) for l in lines), default=0)
    return [l.ljust(max_width) for l in lines]


def find_corners(grid: list[str]) -> list[Corner]:
    """Find all '+' positions."""
    corners = []
    for r, line in enumerate(grid):
        for c, ch in enumerate(line):
            if ch == "+":
                corners.append(Corner(r, c))
    return corners


def validate_horizontal_edge(grid: list[str], c1: Corner, c2: Corner) -> list[Issue]:
    """Check that every column between two same-row corners is '-' or '+'."""
    issues = []
    row = c1.row
    for col in range(c1.col + 1, c2.col):
        ch = grid[row][col]
        if ch not in ("-", "+"):
            issues.append(Issue(
                "error",
                f"Horizontal border broken: expected '-' or '+', got '{ch}'",
                row, col,
                fix_hint=f"Change '{ch}' to '-' at row {row}, col {col}"
            ))
    return issues


def validate_vertical_edge(grid: list[str], c1: Corner, c2: Corner) -> list[Issue]:
    """Check that every row between two same-col corners is '|' or '+'."""
    issues = []
    col = c1.col
    for row in range(c1.row + 1, c2.row):
        ch = grid[row][col]
        if ch not in ("|", "+"):
            issues.append(Issue(
                "error",
                f"Vertical border broken: expected '|' or '+', got '{ch}'",
                row, col,
                fix_hint=f"Change '{ch}' to '|' at row {row}, col {col}"
            ))
    return issues


def discover_boxes(grid: list[str], corners: list[Corner]) -> tuple[list[Box], list[Issue]]:
    """Find valid boxes: rectangles with all 4 corners and valid edges."""
    issues = []
    boxes = []
    corner_set = {(c.row, c.col) for c in corners}

    by_row: dict[int, list[Corner]] = {}
    by_col: dict[int, list[Corner]] = {}
    for c in corners:
        by_row.setdefault(c.row, []).append(c)
        by_col.setdefault(c.col, []).append(c)

    # Precompute valid horizontal edges
    valid_h = set()
    for row, row_corners in by_row.items():
        row_corners.sort(key=lambda c: c.col)
        for i in range(len(row_corners)):
            for j in range(i + 1, len(row_corners)):
                c1, c2 = row_corners[i], row_corners[j]
                if not validate_horizontal_edge(grid, c1, c2):
                    valid_h.add((c1.row, c1.col, c2.col))

    # Precompute valid vertical edges
    valid_v = set()
    for col, col_corners in by_col.items():
        col_corners.sort(key=lambda c: c.row)
        for i in range(len(col_corners)):
            for j in range(i + 1, len(col_corners)):
                c1, c2 = col_corners[i], col_corners[j]
                if not validate_vertical_edge(grid, c1, c2):
                    valid_v.add((c1.col, c1.row, c2.row))

    # Find rectangles
    corners_sorted = sorted(corners, key=lambda c: (c.row, c.col))
    for tl in corners_sorted:
        for br in corners_sorted:
            if br.row <= tl.row or br.col <= tl.col:
                continue
            tr = (tl.row, br.col)
            bl = (br.row, tl.col)
            if tr not in corner_set or bl not in corner_set:
                continue
            top_ok = (tl.row, tl.col, br.col) in valid_h
            bottom_ok = (br.row, tl.col, br.col) in valid_h
            left_ok = (tl.col, tl.row, br.row) in valid_v
            right_ok = (br.col, tl.row, br.row) in valid_v
            if top_ok and bottom_ok and left_ok and right_ok:
                boxes.append(Box(
                    top_left=tl,
                    top_right=Corner(*tr),
                    bottom_left=Corner(*bl),
                    bottom_right=br,
                ))

    return boxes, issues


def find_suspected_boxes(grid: list[str], corners: list[Corner], found_boxes: list[Box]) -> list[Issue]:
    """
    Heuristic: find horizontal border segment pairs at the same columns but
    different rows that have all 4 corners yet weren't discovered as boxes
    (meaning an edge is broken). Reports actionable fix hints.
    """
    issues = []
    corner_set = {(c.row, c.col) for c in corners}
    found_set = set()
    for b in found_boxes:
        found_set.add((b.top_left.row, b.top_left.col, b.bottom_right.row, b.bottom_right.col))

    # Find all horizontal border segments: +---...---+
    h_segments = []
    for r, line in enumerate(grid):
        c = 0
        while c < len(line):
            if line[c] == "+":
                end = c + 1
                while end < len(line) and line[end] in ("-", "+"):
                    end += 1
                if end > c + 2 and line[end - 1] == "+":
                    h_segments.append((r, c, end - 1))
                c = end
            else:
                c += 1

    # Group by (left_col, right_col) to find potential top/bottom pairs
    by_cols = {}
    for (row, left, right) in h_segments:
        key = (left, right)
        by_cols.setdefault(key, []).append(row)

    for (left, right), rows in by_cols.items():
        rows.sort()
        # Only check ADJACENT pairs (no intermediate segment between them)
        # to avoid combinatorial explosion with many stacked boxes
        for i in range(len(rows) - 1):
            top_row, bot_row = rows[i], rows[i + 1]
            box_key = (top_row, left, bot_row, right)
            if box_key in found_set:
                continue
            has_tl = (top_row, left) in corner_set
            has_tr = (top_row, right) in corner_set
            has_bl = (bot_row, left) in corner_set
            has_br = (bot_row, right) in corner_set
            if not (has_tl and has_tr and has_bl and has_br):
                continue

            # All 4 corners present, edges must be broken
            left_bad = []
            right_bad = []
            has_any_pipe = False
            for row in range(top_row + 1, bot_row):
                if grid[row][left] not in ("|", "+"):
                    left_bad.append(row)
                else:
                    has_any_pipe = True
                if grid[row][right] not in ("|", "+"):
                    right_bad.append(row)
                else:
                    has_any_pipe = True
                # Also check if there's a pipe anywhere in the span
                # (even misaligned) -- evidence of attempted box structure
                if not has_any_pipe:
                    span = grid[row][left:right + 1]
                    if "|" in span:
                        has_any_pipe = True

            # Skip if the gap is pure whitespace (just spacing between
            # separate stacked boxes, not a broken box)
            if not has_any_pipe:
                continue

            if left_bad or right_bad:
                detail_parts = []
                if left_bad:
                    detail_parts.append(
                        f"left border broken at row(s) {left_bad} col {left}")
                if right_bad:
                    detail_parts.append(
                        f"right border broken at row(s) {right_bad} col {right}")
                issues.append(Issue(
                    "warning",
                    f"Suspected incomplete box ({top_row},{left})->({bot_row},{right}): "
                    + "; ".join(detail_parts),
                    top_row, left,
                    fix_hint="Align '|' characters to match corner columns"
                ))

    # Detect off-by-one misaligned top/bottom borders
    # Group segments by left column
    by_left: dict[int, list[tuple[int, int]]] = {}  # left -> [(row, right), ...]
    for (row, left, right) in h_segments:
        by_left.setdefault(left, []).append((row, right))

    reported_misalign = set()
    for left, segs in by_left.items():
        segs.sort()
        for i in range(len(segs) - 1):
            row1, right1 = segs[i]
            row2, right2 = segs[i + 1]
            diff = abs(right1 - right2)
            if diff == 1:
                pair_key = (left, min(right1, right2), max(right1, right2))
                if pair_key in reported_misalign:
                    continue
                reported_misalign.add(pair_key)
                # Check neither combo is a found box
                k1 = (row1, left, row2, right1)
                k2 = (row1, left, row2, right2)
                if k1 not in found_set and k2 not in found_set:
                    shorter_row = row1 if right1 < right2 else row2
                    shorter_end = min(right1, right2)
                    longer_end = max(right1, right2)
                    issues.append(Issue(
                        "warning",
                        f"Possible misaligned box: borders at rows {row1} and {row2} "
                        f"share left col {left} but right ends differ "
                        f"(col {shorter_end} vs col {longer_end}, off by 1)",
                        shorter_row, shorter_end,
                        fix_hint=f"Extend border at row {shorter_row} to end at col {longer_end}"
                    ))

    return issues


def validate_padding(grid: list[str], box: Box) -> list[Issue]:
    """Padding must be exactly 1 space on each side of content."""
    issues = []
    tl = box.top_left
    br = box.bottom_right

    for row in range(tl.row + 1, br.row):
        line = grid[row]
        left_pad_col = tl.col + 1
        if left_pad_col < len(line) and line[left_pad_col] != " ":
            issues.append(Issue(
                "error",
                f"Left padding missing: expected space, got '{line[left_pad_col]}'",
                row, left_pad_col,
                fix_hint=f"Insert space at row {row}, col {left_pad_col}"
            ))
        right_pad_col = br.col - 1
        if right_pad_col >= 0 and line[right_pad_col] != " ":
            issues.append(Issue(
                "error",
                f"Right padding missing: expected space, got '{line[right_pad_col]}'",
                row, right_pad_col,
                fix_hint=f"Insert space at row {row}, col {right_pad_col}"
            ))
    return issues


def validate_width(grid: list[str], box: Box) -> list[Issue]:
    """Box width == max(len(content_line)) + 4."""
    issues = []
    tl = box.top_left
    br = box.bottom_right
    box_width = br.col - tl.col + 1

    content_lines = []
    for row in range(tl.row + 1, br.row):
        content_start = tl.col + 2
        content_end = br.col - 2
        if content_start <= content_end:
            content = grid[row][content_start:content_end + 1].rstrip()
            content_lines.append(content)

    box.content_lines = content_lines

    if content_lines:
        max_content = max(len(l) for l in content_lines)
        expected_width = max_content + 4
        if box_width < expected_width:
            issues.append(Issue(
                "error",
                f"Box too narrow: width {box_width}, content needs {expected_width}",
                tl.row, tl.col,
                fix_hint=f"Widen box by {expected_width - box_width} columns"
            ))
        elif box_width > expected_width:
            issues.append(Issue(
                "warning",
                f"Box wider than needed: width {box_width}, content needs {expected_width} "
                f"(extra {box_width - expected_width} cols)",
                tl.row, tl.col
            ))

    return issues


def validate_diagram(text: str) -> tuple[list[Box], list[Issue]]:
    """Main validation entry point."""
    grid = load_grid(text)
    all_issues: list[Issue] = []

    corners = find_corners(grid)
    if not corners:
        all_issues.append(Issue("error", "No corners ('+') found in diagram"))
        return [], all_issues

    boxes, discovery_issues = discover_boxes(grid, corners)
    all_issues.extend(discovery_issues)

    if not boxes:
        all_issues.append(Issue("error", "No valid boxes found"))
        by_row: dict[int, list[Corner]] = {}
        by_col: dict[int, list[Corner]] = {}
        for c in corners:
            by_row.setdefault(c.row, []).append(c)
            by_col.setdefault(c.col, []).append(c)
        for row, rc in by_row.items():
            rc.sort(key=lambda c: c.col)
            for i in range(len(rc)):
                for j in range(i + 1, len(rc)):
                    all_issues.extend(validate_horizontal_edge(grid, rc[i], rc[j]))
        for col, cc in by_col.items():
            cc.sort(key=lambda c: c.row)
            for i in range(len(cc)):
                for j in range(i + 1, len(cc)):
                    all_issues.extend(validate_vertical_edge(grid, cc[i], cc[j]))

    for box in boxes:
        all_issues.extend(validate_padding(grid, box))
        all_issues.extend(validate_width(grid, box))

    all_issues.extend(find_suspected_boxes(grid, corners, boxes))

    return boxes, all_issues


def print_report(boxes: list[Box], issues: list[Issue]):
    errors = [i for i in issues if i.severity == "error"]
    warnings = [i for i in issues if i.severity == "warning"]

    print("=== ASCII Box Diagram Validation Report ===")
    print(f"Boxes found: {len(boxes)}")
    for i, box in enumerate(boxes):
        tl, br = box.top_left, box.bottom_right
        w = br.col - tl.col + 1
        h = br.row - tl.row + 1
        content_preview = ""
        non_empty = [l for l in box.content_lines if l.strip()]
        if non_empty:
            content_preview = f' -- "{non_empty[0].strip()}"'
            if len(non_empty) > 1:
                content_preview += f" (+{len(non_empty) - 1} more lines)"
        print(f"  Box {i + 1}: ({tl.row},{tl.col})->({br.row},{br.col}) "
              f"{w}x{h}{content_preview}")

    print(f"\nErrors: {len(errors)}")
    for e in errors:
        print(f"  {e}")

    print(f"Warnings: {len(warnings)}")
    for w in warnings:
        print(f"  {w}")

    if not errors:
        print("\n*** PASSED: No errors found ***")
    else:
        print(f"\n*** FAILED: {len(errors)} error(s) ***")


def json_report(boxes: list[Box], issues: list[Issue]) -> str:
    return json.dumps({
        "boxes": [
            {
                "top_left": [b.top_left.row, b.top_left.col],
                "bottom_right": [b.bottom_right.row, b.bottom_right.col],
                "width": b.width,
                "height": b.height,
                "content": [l for l in b.content_lines if l.strip()],
            }
            for b in boxes
        ],
        "errors": [i.to_dict() for i in issues if i.severity == "error"],
        "warnings": [i.to_dict() for i in issues if i.severity == "warning"],
        "passed": not any(i.severity == "error" for i in issues),
    }, indent=2)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Validate ASCII box diagrams")
    parser.add_argument("file", help="Path to diagram file")
    parser.add_argument("--json", action="store_true", help="Output JSON report")
    args = parser.parse_args()

    with open(args.file, "r") as f:
        text = f.read()

    # Strip markdown fences if present
    lines = text.split("\n")
    if lines and lines[0].strip().startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip().startswith("```"):
        lines = lines[:-1]
    text = "\n".join(lines)

    boxes, issues = validate_diagram(text)

    if args.json:
        print(json_report(boxes, issues))
    else:
        print_report(boxes, issues)

    sys.exit(1 if any(i.severity == "error" for i in issues) else 0)
