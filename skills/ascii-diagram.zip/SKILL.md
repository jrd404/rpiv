---
name: ascii-diagram
description: >
  Create, validate, fix, and edit ASCII box diagrams in code and documentation files.
  Use this skill whenever the user mentions ASCII diagrams, box diagrams, text diagrams,
  or asks to "draw" or "diagram" something in plain text. Also trigger when the user
  uploads an image of a diagram and wants it converted to ASCII, or when they paste or
  upload a broken ASCII diagram that needs fixing. Trigger on phrases like: "make an
  ASCII diagram", "convert this diagram to text", "fix this ASCII diagram", "add a box
  to the diagram", "validate the diagram", "draw this as ASCII", "text-based diagram",
  or any reference to editing boxes, arrows, or layout in a plain-text diagram. If the
  user has a .md, .txt, or code file containing an ASCII diagram, this skill handles it.
---

# ASCII Diagram Skill

Create, validate, fix, and interactively edit ASCII box diagrams.

## Before You Start

1. Read `references/box-spec.md` for the canonical rules on box structure, arrows,
   and layout patterns. Follow these rules for ALL diagram operations.
2. The validator script is at `scripts/validate_ascii.py`. Run it after every
   generation or edit to catch structural errors.

## Modes

This skill operates in five modes. Determine which mode applies from the user's
request, then follow the corresponding section.

### Mode 1: Generate a Diagram

When the user asks to create a new ASCII diagram from a description, context,
or conceptual input.

**Steps:**

1. Identify the components (boxes) and their relationships (arrows).
2. Decide on layout: columns for parallel concepts, vertical stacking for
   sequential flow, side-by-side for comparison.
3. Pick a uniform box width per column. All boxes in the same column should
   share the same width for visual alignment.
4. Draw the diagram following box-spec.md rules:
   - `+` at corners, `-` for horizontal borders, `|` for vertical borders
   - Exactly 1 space of padding inside each border
   - Content centered or left-aligned within the padded area
5. Add arrows (`-->`, `<--`, `|` + `v`, `|` + `^`) between boxes.
6. Add free-floating labels (titles, annotations) outside boxes.
7. Save the diagram to a file, then run the validator:
   ```bash
   python3 SKILL_DIR/scripts/validate_ascii.py diagram_file.txt
   ```
8. Fix any errors the validator reports. Re-run until PASSED.

**Target file detection:** If the user's request implies the diagram belongs in
a specific file (e.g., "add an architecture diagram to README.md"), identify
that file, determine the insertion point, and write the diagram there (inside
a markdown code fence if the target is .md). If no target file is implied,
create a standalone .txt file.

### Mode 2: Convert an Image to ASCII

When the user uploads an image (screenshot, photo, or URL) of a diagram and
wants it as ASCII text.

**Steps:**

1. Examine the image carefully. Identify every box, its label/content, and
   all arrows or connections.
2. Identify the spatial layout: which boxes are side-by-side, which are
   stacked, which are nested.
3. Transcribe into ASCII following the same generation steps as Mode 1.
4. Validate with the script. The most common errors from image conversion are:
   - Off-by-one column alignment (content row borders shifted vs corner rows)
   - Inconsistent box widths within a column
   - Missing or extra characters in arrow shafts
5. Compare your ASCII output against the original image: count the boxes,
   verify all labels match, confirm arrow directions are correct.

**Important:** When the source image has nested containers (e.g., a "Parent"
box containing sub-boxes), prefer labeled columns over true nesting unless the
user specifically asks for nested boxes. Nested boxes with arrows crossing
outer borders are fragile and hard to maintain.

### Mode 3: Validate and Fix an Existing Diagram

When the user has a diagram (in a file, pasted, or in a code block) that may
have errors.

**Steps:**

1. Extract the diagram text. If wrapped in markdown fences, strip them before
   validating (the script handles this automatically).
2. Run the validator:
   ```bash
   python3 SKILL_DIR/scripts/validate_ascii.py <file> --json
   ```
3. Read the JSON output. For each error:
   - Identify the exact row and column of the problem.
   - Use `fix_hint` from the report if available.
   - Use `str_replace` (or direct file edit) to fix one issue at a time.
4. Re-run the validator after each fix to confirm resolution and avoid
   cascading edits.
5. After all errors are fixed, check warnings:
   - "Box wider than needed" is usually fine (intentional column alignment).
   - "Suspected incomplete box" means a box was partially formed but not
     detected -- investigate these, they often indicate the real problem.
   - "Possible misaligned box" indicates off-by-one errors between top and
     bottom borders.
6. Show the user the before/after diff or the final validated result.

**Common fix patterns:**
- **Off-by-one border:** A `|` on a content row is 1 column left or right of
  where the `+` corners are. Fix by adding or removing a space.
- **Missing dash in border:** A top or bottom border is 1 character short.
  Add a `-` before the closing `+`.
- **Stray space in border:** A space appears inside a `+---+` run, breaking
  the horizontal edge. Remove the space.
- **Misaligned content row:** The `|` chars on content rows don't align with
  the corner `+` chars. Inspect character-by-character at the column positions
  reported by the validator.

### Mode 4: Interactive Editing

When the user wants to modify an existing diagram -- adding, removing, or
changing boxes or connections.

**Steps:**

1. Parse the current diagram to understand its structure (run validator with
   `--json` to get box positions and content).
2. Present the user with choices using `ask_user_input`. Each option label
   should be a truncated beginning of the box content or a short description
   of the component. Examples:
   - "Which box to edit?" with options like `Task()`, `User message`, `Base`
   - "Where to add the new box?" with options like `Below "Task()"`,
     `Right of "Base"`, `New column`
   - "Arrow direction?" with options like `Left to right`, `Right to left`,
     `Top to bottom`
3. Apply the edit following box-spec.md rules.
4. Validate after every edit.
5. Present the result and ask if further edits are needed.

**When offering box choices**, use the first non-empty content line of each
box, truncated to ~20 characters if needed. This keeps the UI compact while
still identifiable.

### Mode 5: Derive Target File and Insert

When generating or fixing a diagram that should live inside an existing file.

**Steps:**

1. Determine the target file:
   - Explicit: user says "add to README.md" or "put it in docs/arch.md"
   - Implicit: user is working on a file that has a section like
     `## Architecture` or `<!-- diagram here -->`
   - Default: create a new standalone file
2. Determine the insertion format:
   - `.md` files: wrap in triple-backtick code fence (no language tag, or
     use `text` if the user prefers)
   - `.txt` files: insert raw
   - Source code files (`.py`, `.js`, etc.): wrap in comment block
     appropriate to the language
3. Insert or replace the diagram at the correct position.
4. Validate the diagram portion (extract from fences if needed).

## Validator Reference

The validator script supports two output modes:

**Human-readable (default):**
```bash
python3 scripts/validate_ascii.py diagram.txt
```

**JSON (for programmatic use):**
```bash
python3 scripts/validate_ascii.py diagram.txt --json
```

JSON output structure:
```json
{
  "boxes": [
    {
      "top_left": [row, col],
      "bottom_right": [row, col],
      "width": N,
      "height": N,
      "content": ["line1", "line2"]
    }
  ],
  "errors": [
    {"severity": "error", "message": "...", "row": N, "col": N, "fix_hint": "..."}
  ],
  "warnings": [...],
  "passed": true/false
}
```

The script auto-strips markdown fences if present in the input file.

## Quality Checklist

Before presenting a diagram to the user, verify:

- [ ] Validator reports 0 errors
- [ ] All intended boxes are detected (check box count)
- [ ] Box content matches what was requested
- [ ] Arrows point in the correct direction
- [ ] Column alignment is consistent (same-column boxes share width)
- [ ] Free-floating labels don't overlap with box borders
- [ ] If targeting a file, the diagram is correctly inserted and formatted
